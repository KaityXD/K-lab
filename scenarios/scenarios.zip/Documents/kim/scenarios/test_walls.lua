function onStart()
	print("Target Switching Test started")
	clearTargets()
	clearWalls()

	-- Spawn walls
	spawnWall(0, 5, -13, 20, 10, 1, { 1, 1, 1 })

	-- Spawn a target with 500 HP (needs 5 shots)
	-- spawnTarget(x, y, z, radius, shape, color, velocity, lifetime, health)
	spawnTarget(0, 5, -9.5, 0.5, TargetShape.SPHERE, { 1, 0, 0 }, { 0, 0, 0 }, 0, 500)

	-- Spawn some normal targets
	spawnTarget(-3, 3, -9.5, 0.4, TargetShape.BOX, { 0, 1, 0 })
	spawnTarget(3, 7, -9.5, 0.4, TargetShape.BEAN, { 0, 0, 1 })
end

function onUpdate(dt) end

function onHit(x, y, z)
	-- If no targets left, spawn a new tanky one
	if getTargetCount() == 0 then
		spawnTarget(
			math.random(-5, 5),
			math.random(2, 8),
			-9.5,
			0.5,
			TargetShape.SPHERE,
			{ 1, 0, 0 },
			{ 0, 0, 0 },
			0,
			500
		)
	end
end
